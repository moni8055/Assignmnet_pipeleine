package com.nagarro.csvreader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nagarro.model.Tshirt;
import com.nagarro.session.HibernateUtil;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

public class ReadCsvData {
	public static void readFromCSV() {
		String directoryPath = "C:\\Users\\CSV Files";
		File[] filesInDirectory = new File(directoryPath).listFiles();
		for (File f : filesInDirectory) {
			String filePath = f.getAbsolutePath();
			String fileExtenstion = filePath.substring(filePath.lastIndexOf(".") + 1, filePath.length());
			if ("csv".equals(fileExtenstion)) {

				try {
					CSVReader csvReader = new CSVReaderBuilder(new FileReader(filePath)).withSkipLines(1).build();
					String[] nextRecord;

					try {
						Transaction tx = null;
						while ((nextRecord = csvReader.readNext()) != null) {
							try {
								String[] record = nextRecord[0].split("\\|");
								Tshirt tshirt = new Tshirt();
								Session session = HibernateUtil.getSessionFactory().openSession();
								tx = session.beginTransaction();
								tshirt.setId(record[0]);
								tshirt.setName(record[1]);
								tshirt.setColour(record[2]);
								tshirt.setGender(record[3]);
								tshirt.setSize(record[4]);
								tshirt.setPrice(Double.valueOf(record[5]));
								tshirt.setRating(Double.valueOf(record[6]));
								tshirt.setAvailability(record[7].compareTo("Y") == 0 ? Boolean.TRUE : Boolean.FALSE);
								session.save(tshirt);
								tx.commit();
								session.close();
							} catch (Exception exp) {
								tx.rollback();
							}
						}

					} catch (CsvValidationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}

		}
	}
}
