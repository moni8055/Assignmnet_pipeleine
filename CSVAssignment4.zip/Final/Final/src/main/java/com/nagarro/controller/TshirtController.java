package com.nagarro.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.dao.TshirtDao;
import com.nagarro.dto.DtoInput;
import com.nagarro.model.Tshirt;

@Controller
public class TshirtController {

	@RequestMapping(path ="/SearchProduct", method = RequestMethod.POST)
	public ModelAndView Search(@ModelAttribute DtoInput dt) {
		System.out.println(dt);
		List<Tshirt> result = TshirtDao.SearchTshirt(dt);
		if (result.isEmpty()) {
			System.out.println("No Tshirt Available");
		}
		ModelAndView andView = new ModelAndView();
		andView.addObject("result", result);
		return andView;
	}

}
